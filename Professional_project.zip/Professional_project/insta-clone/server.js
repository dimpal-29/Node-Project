const express = require("express");

const app = express();
app.use(express.json());

const PORT = 3000;

const users = [
  {
    userId: 1,
    username: "dimple_narkhede",
    followers: 1200,
    bio: "Frontend Developer | MERN Learner"
  },
  {
    userId: 2,
    username: "riya_patel",
    followers: 850,
    bio: "Travel lover ✈️ | Photographer"
  },
  {
    userId: 3,
    username: "rahul_shah",
    followers: 2100,
    bio: "Developer | Tech enthusiast 💻"
  },
  {
    userId: 4,
    username: "neha_mehta",
    followers: 1500,
    bio: "Fashion | Lifestyle | Food"
  },
  {
    userId: 5,
    username: "arjun_verma",
    followers: 980,
    bio: "Fitness | Photography | Travel"
  }
];

const posts = [
  {
    postId: 1,
    username: "dimple_narkhede",
    imageUrl: "https://example.com/photo1.jpg",
    caption: "Enjoying my day ✨",
    likes: 25
  },
  {
    postId: 2,
    username: "riya_patel",
    imageUrl: "https://example.com/photo2.jpg",
    caption: "Beautiful travel memories ❤️",
    likes: 42
  },
  {
    postId: 3,
    username: "rahul_shah",
    imageUrl: "https://example.com/photo3.jpg",
    caption: "Working on something new 💻",
    likes: 35
  },
  {
    postId: 4,
    username: "neha_mehta",
    imageUrl: "https://example.com/photo4.jpg",
    caption: "Weekend vibes 🌸",
    likes: 58
  },
  {
    postId: 5,
    username: "arjun_verma",
    imageUrl: "https://example.com/photo5.jpg",
    caption: "Fitness goals 💪",
    likes: 31
  },
  {
    postId: 6,
    username: "dimple_narkhede",
    imageUrl: "https://example.com/photo6.jpg",
    caption: "Coffee and coding ☕💻",
    likes: 67
  },
  {
    postId: 7,
    username: "riya_patel",
    imageUrl: "https://example.com/photo7.jpg",
    caption: "Sunset is beautiful 🌅",
    likes: 49
  },
  {
    postId: 8,
    username: "rahul_shah",
    imageUrl: "https://example.com/photo8.jpg",
    caption: "Learning new technologies 🚀",
    likes: 29
  },
  {
    postId: 9,
    username: "neha_mehta",
    imageUrl: "https://example.com/photo9.jpg",
    caption: "Simple moments, happy life ❤️",
    likes: 76
  },
  {
    postId: 10,
    username: "arjun_verma",
    imageUrl: "https://example.com/photo10.jpg",
    caption: "Another productive day 🔥",
    likes: 54
  }
];

app.get("/profile", (req, res) => {
  res.json(users);
});


app.post("/post", (req, res) => {
  const { imageUrl, caption } = req.body;

  const newPost = {
    postId: posts.length + 1,
    imageUrl: imageUrl,
    caption: caption,
    likes: 0
  };

  posts.push(newPost);

  res.json(newPost);
});


app.get("/feed", (req, res) => {
  const feed = [...posts].reverse();

  res.json(feed);
});


app.post("/like", (req, res) => {
  const postId = Number(req.body.postId);

  const post = posts.find((post) => post.postId === postId);

  if (!post) {
    return res.status(404).json({
      message: "Post not found"
    });
  }

  post.likes++;

  res.json({
    postId: post.postId,
    likes: post.likes
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});