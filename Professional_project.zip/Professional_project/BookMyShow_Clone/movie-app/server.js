const express = require("express");
const movieRoutes = require("./movieRoutes");

const app = express();

const PORT = 3000;

const bookedSeats = ["A1", "A2", "B5"];

app.use(express.json());

app.use("/", movieRoutes);


function isSeatBooked(bookedSeats, seatNumber) {
  return bookedSeats.includes(seatNumber);
}

app.post("/book-ticket", (req, res) => {
  const { movieId, seatNumber, userEmail } = req.body;

  if (isSeatBooked(bookedSeats, seatNumber)) {
    return res.status(400).json({
      message: "Seat is already booked"
    });
  }

  bookedSeats.push(seatNumber);

  res.json({
    message: "Ticket booked successfully",
    movieId,
    seatNumber,
    userEmail
  });
});

app.use((err, req, res, next) => {
  console.error(err.message);

  res.status(500).json({
    message: "Something went wrong",
    error: err.message
  });
});


app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});