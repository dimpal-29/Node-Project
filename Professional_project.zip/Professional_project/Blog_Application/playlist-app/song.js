class Song {
  constructor(title, artist, duration) {
    this.title = title;
    this.artist = artist;
    this.duration = duration;
  }
}

const songs = [
  new Song("Perfect", "Ed Sheeran", 263),
  new Song("Believer", "Imagine Dragons", 204),
  new Song("Kesariya", "Arijit Singh", 268)
];

module.exports = songs;
module.exports.Song = Song;