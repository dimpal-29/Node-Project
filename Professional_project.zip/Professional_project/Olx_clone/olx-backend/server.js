const express = require("express");
const multer = require("multer");

const app = express();

const PORT = 3000;

app.use(express.json());

const upload = multer({
  dest: "uploads/"
});

const products = [
  {
    id: 1,
    title: "iPhone 13",
    price: 45000,
    imageUrl: "https://example.com/iphone.jpg"
  },
  {
    id: 2,
    title: "Dell Laptop",
    price: 35000,
    imageUrl: "https://example.com/laptop.jpg"
  },
  {
    id: 3,
    title: "Royal Enfield Bike",
    price: 120000,
    imageUrl: "https://example.com/bike.jpg"
  },
  {
    id: 4,
    title: "Sofa Set",
    price: 18000,
    imageUrl: "https://example.com/sofa.jpg"
  },
  {
    id: 5,
    title: "Samsung TV",
    price: 28000,
    imageUrl: "https://example.com/tv.jpg"
  }
];

app.get("/products", (req, res) => {
  res.json(products);
});

app.post("/add-product", (req, res) => {
  const { title, price, imageUrl } = req.body;

  const newProduct = {
    id: products.length + 1,
    title: title,
    price: price,
    imageUrl: imageUrl
  };

  products.push(newProduct);

  res.json(products);
});

app.get("/products/:id", (req, res) => {
  const id = Number(req.params.id);

  const product = products.find((product) => product.id === id);

  if (!product) {
    return res.status(404).json({
      message: "Product not found"
    });
  }

  res.json(product);
});

app.delete("/products/:id", (req, res) => {
  const id = Number(req.params.id);

  const product = products.find((product) => product.id === id);

  if (!product) {
    return res.status(404).json({
      message: "Product not found"
    });
  }

  const updatedProducts = products.filter(
    (product) => product.id !== id
  );

  products.length = 0;
  products.push(...updatedProducts);

  res.json(products);
});


app.post("/upload", upload.single("image"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({
      message: "Image is required"
    });
  }

  res.json({
    message: "Image uploaded successfully",
    file: req.file
  });
});


app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});