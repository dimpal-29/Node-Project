const express = require("express");

const app = express();
const PORT = 3000;

const logger = (req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
};

app.use(logger);


const products = [
  {
    id: 1,
    name: "T-Shirt",
    price: 499
  },
  {
    id: 2,
    name: "Jeans",
    price: 999
  },
  {
    id: 3,
    name: "Shoes",
    price: 1499
  }
];

const cart = [];

function addToCart(productId, quantity) {
  const product = products.find((product) => product.id === productId);

  if (!product) {
    return "Product not found";
  }

  const cartItem = cart.find((item) => item.productId === productId);

  if (cartItem) {
    cartItem.quantity += quantity;
  } else {
    cart.push({
      productId: product.id,
      name: product.name,
      price: product.price,
      quantity: quantity
    });
  }

  return cart;
}

addToCart(1, 2);
addToCart(2, 1);

app.get("/cart/total", (req, res) => {
  let subtotal = 0;

  cart.forEach((item) => {
    subtotal += item.price * item.quantity;
  });

  const deliveryCharge = subtotal * 0.05;

  const total = subtotal + deliveryCharge;

  res.json({
    subtotal: subtotal,
    deliveryCharge: deliveryCharge,
    total: total
  });
});

app.get("/products/search", (req, res) => {
  const search = req.query.name || "";

  const result = products.filter((product) =>
    product.name.toLowerCase().includes(search.toLowerCase())
  );

  res.json(result);
});



app.get("/products", (req, res) => {
  res.json(products);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});