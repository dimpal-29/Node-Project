const express = require("express");
const Room = require("./room");

const app = express();

const PORT = 3000;

const rooms = [
  new Room(
    "Luxury Sea View Apartment",
    "Goa",
    4500,
    ["WiFi", "AC", "Balcony", "Swimming Pool", "Breakfast"]
  ),

  new Room(
    "Cozy Heritage Room",
    "Jaipur",
    2800,
    ["WiFi", "AC", "TV", "Breakfast"]
  ),

  new Room(
    "Modern City Apartment",
    "Mumbai",
    3500,
    ["WiFi", "AC", "Kitchen", "Parking"]
  ),

  new Room(
    "Peaceful Garden Villa",
    "Ahmedabad",
    3000,
    ["WiFi", "AC", "Garden", "Parking", "TV"]
  ),

  new Room(
    "Mountain View Cottage",
    "Manali",
    3800,
    ["WiFi", "Heating", "Balcony", "Parking", "Breakfast"]
  )
];

app.get("/", (req, res) => {
  res.send("Welcome to StayEZ");
});

app.get("/rooms", (req, res) => {
  res.json(rooms);
});

app.get("/rooms/search", (req, res) => {
  const location = req.query.location || "";

  const results = rooms.filter(
    (room) =>
      room.location.toLowerCase() === location.toLowerCase()
  );

  res.json(results);
});

app.listen(PORT, () => {
  console.log(`StayEZ server running on http://localhost:${PORT}`);
});

