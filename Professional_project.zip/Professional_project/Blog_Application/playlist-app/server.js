const express = require("express");
const songs = require("./song");
const Song = require("./song").Song;

const app = express();
app.use(express.json());

const PORT = 3000;

app.get("/", (req, res) => {
  res.send("Welcome to Playlist App");
});

app.get("/songs", (req, res) => {
  res.json(songs);
});

app.post("/songs", (req, res) => {
  const { title, artist, duration } = req.body;

  if (!title || title.trim() === "") {
    return res.status(400).json({
      message: "Title is required"
    });
  }

  if (typeof duration !== "number" || duration <= 0) {
    return res.status(400).json({
      message: "Duration must be a positive number"
    });
  }

  const newSong = new Song(title, artist, duration);

  songs.push(newSong);

  res.json(songs);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});