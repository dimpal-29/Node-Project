const express = require("express");
const path = require("path");
const multer = require("multer");

const app = express();

const PORT = 3000;
app.use(express.json());


const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },

  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  }
});

const upload = multer({ storage: storage });

app.use("/uploads", express.static("uploads"));

const templates = [
  {
    id: 1,
    name: "Birthday Poster",
    imageUrl: "https://example.com/birthday.jpg"
  },
  {
    id: 2,
    name: "Wedding Poster",
    imageUrl: "https://example.com/wedding.jpg"
  },
  {
    id: 3,
    name: "Business Poster",
    imageUrl: "https://example.com/business.jpg"
  },
  {
    id: 4,
    name: "Festival Poster",
    imageUrl: "https://example.com/festival.jpg"
  },
  {
    id: 5,
    name: "Sale Poster",
    imageUrl: "https://example.com/sale.jpg"
  }
];

const designs = [];



app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

app.get("/templates", (req, res) => {
  res.json(templates);
});

app.post("/design", (req, res) => {
  const { text, templateId } = req.body;

  const template = templates.find(
    (template) => template.id === templateId
  );

  if (!template) {
    return res.status(404).json({
      message: "Template not found"
    });
  }

  const design = {
    id: designs.length + 1,
    text: text,
    templateId: template.id,
    templateName: template.name,
    imageUrl: template.imageUrl,
    backgroundColor: "white"
  };

  designs.push(design);

  res.json(design);
});

app.post("/design/background", (req, res) => {
  const { designId, backgroundColor } = req.body;

  const design = designs.find(
    (design) => design.id === designId
  );

  if (!design) {
    return res.status(404).json({
      message: "Design not found"
    });
  }

  design.backgroundColor = backgroundColor;

  res.json({
    message: "Background color updated",
    design: design
  });
});

app.post("/upload", upload.single("image"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({
      message: "Please upload an image"
    });
  }

  const fileUrl = `/uploads/${req.file.filename}`;

  res.json({
    message: "Image uploaded successfully",
    imageUrl: fileUrl
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});