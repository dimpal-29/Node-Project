const express = require("express");

const router = express.Router();

const movies = [
  {
    id: 1,
    title: "Avatar 3",
    language: "English",
    releaseDate: "2026-12-18"
  },
  {
    id: 2,
    title: "Pushpa 3",
    language: "Telugu",
    releaseDate: "2026-08-15"
  },
  {
    id: 3,
    title: "War 2",
    language: "Hindi",
    releaseDate: "2026-08-14"
  },
  {
    id: 4,
    title: "Kantara 2",
    language: "Kannada",
    releaseDate: "2026-10-02"
  },
  {
    id: 5,
    title: "Housefull 5",
    language: "Hindi",
    releaseDate: "2026-06-06"
  }
];

router.get("/movies", (req, res) => {
  res.json(movies);
});

router.get("/search-movies", (req, res) => {
  const searchTerm = req.query.q || "";

  const results = movies.filter((movie) =>
    movie.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  res.json(results);
});

module.exports = router;